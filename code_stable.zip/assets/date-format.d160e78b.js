const a=t=>new Date(t).toLocaleDateString("fr-FR",{day:"2-digit",month:"long",year:"numeric"}),e=a;export{e as f};
